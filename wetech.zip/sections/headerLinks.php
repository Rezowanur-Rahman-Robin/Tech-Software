	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="media/favicon.png">

	<!-- Dependency Styles -->
	<link rel="stylesheet" href="dependencies/bootstrap/css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/fontawesome/css/all.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/select2/css/select2.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/flaticon/flaticon.css" type="text/css">
	<link rel="stylesheet" href="dependencies/wow/css/animate.css" type="text/css">
	<link rel="stylesheet" href="dependencies/page-piling/css/jquery.pagepiling.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/nivo-slider/css/nivo-slider.css" type="text/css">
	<link rel="stylesheet" href="dependencies/meanmenu/css/meanmenu.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/magnific-popup/css/magnific-popup.css" type="text/css">
	<link rel="stylesheet" href="dependencies/owl.carousel/css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/owl.carousel/css/owl.theme.default.min.css" type="text/css">
	<link rel="stylesheet" href="dependencies/slick/css/slick.css" type="text/css">
	<link rel="stylesheet" href="dependencies/slick/css/slick-theme.css" type="text/css">

	<!-- Site Stylesheet -->
	<link rel="stylesheet" href="assets/css/app.css" type="text/css">
	<!-- Animation Stylesheet -->
	<link rel="stylesheet" href="dependencies/animation-css/animation-css.css" type="text/css">

	<!-- Google Web Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">