<!--=====================================-->
			<!--=            Navbar Start           =-->
			<!--=====================================-->
			<header class="sticky-on">
				<div id="sticky-placeholder"></div>
				<div id="navbar-wrap" class="navbar-wrap">
					<div class="navbar-layout1">
						<div class="container">
							<div class="row no-gutters d-flex align-items-center position-relative">
								<div class="col-lg-2 d-flex justify-content-start">
									<div class="temp-logo text-center">
										<a href="index.php" class="default-logo">
						<img src="media/we_tech-logo.png" alt="logo" class="img-fluid logoCls">
					</a>
										<a href="index.php" class="sticky-logo">
						<img src="media/we_tech-logo.png" alt="logo" class="img-fluid logoCls">
					</a>
									</div>
								</div>
								<div class="col-lg-7 d-flex justify-content-end possition-static">
									<nav id="dropdown" class="template-main-menu">
										<ul>
											<li class="position-static d-none d-lg-block">
												<a href="index.php">Home</a>

											</li>
											
											<li class="d-block d-lg-none">
												<a href="index.php">Home</a>
											</li>

											<li>
												<a href="aboutUs.php">About Us</a>
												
											</li>
											<li>
												<a href="serviceDetails.php">Services</a>
											
											</li>
											<li>
												<a href="allproject.php">Projects</a>
											
											</li>
											<li>
												<a href="career.php">Career</a>
											
											</li>
											
											<li>
												<a href="contact.php"><span>Contact</span></a>
											</li>
										</ul>
									</nav>
								</div>
								<div class="col-lg-3 d-flex justify-content-end">
									<ul class="header-action-items">
										
										<li class="single-item">
											<button type="button" class="offcanvas-menu-btn menu-status-open">
		                    <span class="menu-btn-icon">
		                        <span></span>
		                        <span></span>
		                        <span></span>
		                    </span>
		                </button>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>


				</div>
			</header>
			<!--=====================================-->
			<!--=              Navbar End           =-->
			<!--=====================================-->
			<!--=====================================-->