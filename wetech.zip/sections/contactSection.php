
			<!--=====================================-->
			<!--=   Contact Section Area Start      =-->
			<!--=====================================-->
			<section id="contactSection" class="contact-wrap-layout1 section-padding-md bg-color-light">
				<div class="container">
					<div class="row gutters-50">
						<div class="col-xl-5 col-lg-6 col-12">
							<div class="contact-box-layout1 has-animation">
								<div class="translate-bottom-50 opacity-animation transition-100 transition-delay-100">
									<h2 class="item-title">How May We Help You!</h2>
								</div>
								<div class="translate-bottom-50 opacity-animation transition-100 transition-delay-400">
									<p>Grursus mal suada faci lisis Lorem ipsum consectetur elit.</p>
								</div>
								<form class="contact-form-box" id="contact-form">
									<div class="row gutters-20">
										<div class="col-xl-6 form-group">
											<div class="translate-bottom-75 opacity-animation transition-150 transition-delay-400">
												<input type="text" placeholder="Name *" class="form-control" name="first_name" data-error="Phone field is required" required>
												<div class="help-block with-errors"></div>
											</div>
										</div>
										<div class="col-xl-6 form-group">
											<div class="translate-bottom-75 opacity-animation transition-150 transition-delay-700">
												<input type="email" placeholder="Email *" class="form-control" name="email" data-error="Subject field is required" required>
												<div class="help-block with-errors"></div>
											</div>
										</div>
									
										<div class="col-12 form-group">
											<div class="translate-bottom-75 opacity-animation transition-150 transition-delay-1300">
												<textarea placeholder="Let us know what you need" class="textarea form-control" name="message" id="form-message" rows="7" cols="20" data-error="Message field is required" required></textarea>
												<div class="help-block with-errors"></div>
											</div>
										</div>
										<div class="col-12 form-group mb-0">
											<div class="translate-bottom-75 opacity-animation transition-150 transition-delay-1700">
												<button type="submit" class="btn-fill btn-gradient">Send Message</button>
											</div>
										</div>
									</div>
									<div class="form-response"></div>
								</form>
							</div>
						</div>
						<div class="col-xl-7 col-lg-6 col-12 d-flex align-items-center">
							<div class="contact-box-layout1 has-animation">
								<div class="translate-right-75 transition-150 opacity-animation transition-delay-10">
									<div class="item-figure">
										<img src="media/illustration/illustration21.png" alt="Illustration" class="disp">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--=====================================-->
			<!--=    Contact Section Area End       =-->
			<!--=====================================-->